@echo off
setlocal
cd /d "%~dp0"
if "%~1"=="" (
  echo Drag the original Japanese Nadia ROM onto this file.
  pause
  exit /b 1
)
where py >nul 2>nul
if not errorlevel 1 (
  py -3 -X utf8 "%~dp0apply_latest_release.py" "%~1"
  goto finished
)
where python >nul 2>nul
if not errorlevel 1 (
  python -X utf8 "%~dp0apply_latest_release.py" "%~1"
  goto finished
)
if exist "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" (
  "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" -X utf8 "%~dp0apply_latest_release.py" "%~1"
  goto finished
)
echo Python 3 is required.
exit /b 1
:finished
set "patch_result=%errorlevel%"
pause
exit /b %patch_result%
