@echo off
setlocal
cd /d "%~dp0"
if not exist "C:\RetroArch-Win64\retroarch.exe" (
  echo RetroArch was not found at C:\RetroArch-Win64.
  pause
  exit /b 1
)
if not exist "%~dp0opening.wav" (
  echo Extract ALL files from the ZIP before running this launcher.
  pause
  exit /b 1
)
(
  echo core_options_path = "%~dp0nadia_mdplus_core.opt"
  echo global_core_options = "true"
  echo savestate_auto_load = "false"
) > "%~dp0nadia_mdplus_launch.cfg"
"C:\RetroArch-Win64\retroarch.exe" --appendconfig "%~dp0nadia_mdplus_launch.cfg" -L "C:\RetroArch-Win64\cores\genesis_plus_gx_libretro.dll" "%~dp0Nadia_Korean_SRAM35_MDplus_Lyrics_V7.md"
